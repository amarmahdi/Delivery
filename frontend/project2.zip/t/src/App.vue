<template>
  <v-app>
    <router-view/>
  </v-app>
</template>
