<template>
  <v-parallax
    dark
    src="https://images.squarespace-cdn.com/content/v1/5eb2f5532d212a0e2b3f2102/1600021681609-M3GZ2IG3OQEG9LXKIO6N/Home+Page_Edit.1.jpg"
  >
    <v-row
      align="center"
      justify="center"
    >
      <v-col
        class="text-center"
        cols="12"
      >
        <h1 class="text-h4 font-weight-thin mb-4">
          Welcome to Pizza Delivery
        </h1>
        <h4 class="subheading">
           <v-btn>Order Now</v-btn>
        </h4>
      </v-col>
    </v-row>
  </v-parallax>
</template>
